Test module
=========

Role Variables
------------------
path=dict(type='str', required=True), content=dict(type='str', required=True)

License
-------

BSD

Author Information
------------------

Nechaev Vladimir
